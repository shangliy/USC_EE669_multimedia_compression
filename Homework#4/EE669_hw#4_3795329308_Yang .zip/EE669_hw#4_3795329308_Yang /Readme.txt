# EE669 Homework Assignment #4 
# Apr 25, 2015 
# Name: Shanglin Yang 
# ID: 3795329308 
# Email: shangliy@usc.edu 
# compiled on linux gcc

a. Files discribtion 
	There are one folder inside - x264_edited_YANG, correspngding to the time control and motion estemation strategy.

b. Guilde to compile code 
	Replace the c file under the /x264 files with the modified file under the folder x264_edited_YANG with corresponding sub-subfiles;
        then make and sudo make install to rebuild the x264;

c.Guilde for the use 
	Change the flag int emv_enable at the /x264/common/mvpred.c to enable emv when emv_enable=1 ,disable emv when emv_enable=0  ;  
	Change the flag int ETAR_enable at the /x264/encoder/me.c to enable ETAR when ETAR_enable=1 ,disable ETAR when ETAR_enable=0  ; 
	The time for search will show on the terminal;
	code using the x264:
		x264 --me umh --psnr --tune psnr -o foreman_264_dia.256 --input-res 352x288 foreman_cif.yuv 

	Test each rate control schemes with the Elephants Dream sequence,use the command below:
	Fisrt use the png2yuv - Convert PNG images to the YUV4MPEG stream format.The command is 
	png2yuv  -b 00001  -I  p  -j result.yuv
	Then, use x264 command to do the encoding;
     
	 Video buffer verifier compliant constant bitrate (CBR):
	x264 --demuxer y4m --bitrate 800 --vbv-maxrate 800 --vbv-bufsize 400 --fps 25 --psnr --tune psnr -o ele.mkv --input-res  640x480 result.yuv
	Average Bitrate (ABR):
	x264 --demuxer y4m --bitrate 800 --fps 25 --psnr --tune psnr -o ele.mkv --input-res  640x480 result.yuv 
	Constant rate-factor mode (CRF):
	x264 --demuxer y4m --fps 25 --crf 23 --psnr --tune psnr -o ele.mkv --input-res  640x480 result.yuv 
	Constant quantizer mode (CQP):
	x264 --demuxer y4m --qp 20 --fps 25 --psnr --tune psnr -o ele.mkv --input-res  640x480 result.yuv
	Two pass (2pass):
	x264 --demuxer y4m --pass 1 --crf 25 --fps 25 --psnr --tune psnr -o ele_pass1.mkv --input-res  640x480  result.yuv 
	x264 --demuxer y4m --pass 2 --bitrate 800 --fps 25 --psnr --tune psnr -o ele_pass2.mkv --input-res  640x480   result.yuv
