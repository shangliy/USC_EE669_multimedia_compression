# EE669 Homework Assignment #3 
# Apr 5, 2015 
# Name: Shanglin Yang 
# ID: 3795329308 
# Email: shangliy@usc.edu 
# compiled on linux with codeblocks

a. Files discribtion 
	There are two folder inside,correspngding to the motion vectore extrac and Rate control.
        The file under motion_vector_extract is the modified motion_est.c,it extract the subpixel and full-pixel to the txt file;
        The file under Rate_control is the modified mpegvideo_enc.c,whcih do the buffer rate control.

b. Guilde to compile code 
	Replace the c file under the /ffmpeg-2.5.4/libavcodec files with the modified file;
        then make and sudo make install to rebuild the ffmpeg;

c.Guilde for the use 
	put the input file under the folder using the command :
motion_vector_extract:
ffmpeg  -f rawvideo -vcodec rawvideo  -s 352x288 -r 25 -threads 2 -pix_fmt yuv420p -i foreman_cif.yuv -c:v mpeg2video -me_method epzs  -r 25 -g 12 -b:v 250k -maxrate 250k -minrate 250k -psnr -benchmark -vstats_file foreman_state.txt foreman.mp4
Insert B-frame: 
 ffmpeg  -f rawvideo -vcodec rawvideo  -s 352x288 -r 25 -threads 2 -pix_fmt yuv420p -i foreman_cif.yuv -c:v mpeg2video -me_method epzs  -r 25 -g 12 -b:v 250k -maxrate 250k -minrate 250k -bf 1 -psnr -benchmark -vstats_file foreman_state.txt foreman.mp4
Rate control buffer:
ffmpeg  -f rawvideo -vcodec rawvideo  -s 352x288 -r 25 -threads 2 -pix_fmt yuv420p -i foreman_cif.yuv -c:v mpeg2video -me_method epzs  -r 25 -g 10 -b:v 250k -maxrate 250k -minrate 250k -bufsize 128k -psnr -vstats_file foreman_state_b_ff.txt foreman_buff.mp4
