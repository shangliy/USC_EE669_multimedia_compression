# EE669 Homework Assignment #1 
# Feb 7, 2015 
# Name: Shanglin Yang 
# ID: 3795329308 
# Email: shangliy@usc.edu 
# compiled on WINDOWS 8 with Visul Studio 2015

a. Files discribtion 
	The Zip bag contains only one MFC project-MFCApplication2.sln, The application wizard has created this MFCApplication2 application to finish all problems for the Homework1. The shortscreen of the exe application panel can be seen in the report , and you can also compile the project and get in exe app under the Debug folder. This application not only demonstrates the basics of using the Microsoft Foundation Classes.
	MFCApplication2Dlg.cpp: This is the core source file and implement the function on the pannel.
	MFCApplication2.cpp:This is the main application source file that contains the application class CMFCApplication2App.
	MFCApplication2.vcxproj: This is the main project file for VC++ projects generated using an application wizard.
	MFCApplication2.vcxproj.filters:This is the filters file for VC++ projects generated using an Application Wizard. 
	MFCApplication2.h:This is the main header file for the application.
	bitio.h:main header file for the input and output function
	errhand.h: header file for fatal error.
	MFCApplication2.rc:This is a listing of all of the Microsoft Windows resources that the program uses. 
	res\MFCApplication2.rc2:This file contains resources that are not edited by Microsoft Visual C++.

b. Guilde to compile code 
	Under Visul Studio 2015, double click the MFCApplication2.sln,then the SDE can build the project for you and the program could be compiled. Considering it may require the basic  Microsoft Foundation Classes and toolbox,if there are any problem please contact me.

c.Guilde for the use 
	1,you need to move the data file to the file. If you have already build the exe , you can move files along with the .exe file in the same folder under the debug folder,or you can just move files in under the MFCApplication2 folder.
	you need  to change the name for the different types of your file according to the standards below: 
	image :image.dat.raw
	audio:audio.dat
	text:text.dat
	binary:binary.dat.raw
	2,open the exe or debug the program, choose the file,including binary,audio,test and image.The default sis the test.
	3, click "Input files" to open files ,it will show the imput size of the file and it will also active other button on the right.click  "Entropy" will show the entropy of the file
	4, The right button reprensent different methods of compressing
    	Click "shannon", "Huffman", "Adaptive Huffman",will use the corresponding method the file you choose, and display the outfile size and the compression ratio. Meanwhile, it will also generate hte compressed file with the name "Method_com_Inputfile type" under 		current file direction.
    	Click "Run_lenhth", "Modified_Rl", "Move_F" will use the corresponding method the file you choose,and display the outfile size and the compression ratio. Meanwhile, it will also generate hte compressed file with the name "Method_com_Inputfile type" under current 	file direction. And it will also generate the decoder files named"DECOMethod_com_Inputfile type".
   	For the Modified_Rl,choose RATIO the MTF_ENABLE will Enable the MTF pre-processing for the Modified_Rl,the dault is unable the MTF.
    	Click the PRE_IMAGE will generate the result of modified runlenth using zig zag only for the image-data.
	5,Click the "OK" or "Cancel" will close the program.

d:  Other pertinent information 
	When the input data are big, the AD_huffmane and MTF_HUFFMAN could be kind of slow.(For the sample image data ,it could take 7-10 seconds).Please wait for the application to finish the Encoding.
	PS: This is my first time to finish work like that (no taking the EE569),so if there are any problems with the compiling or debugging considering the environment,please contact me,thank you. 